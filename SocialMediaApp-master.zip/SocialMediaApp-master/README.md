# SocialMediaApp
# A chat application with the following functionalities:

-Search for a specific person

-Chat history

-List of Available contacts

-Mark message as delivered/read

-Users information including profile picture, name etc. updates

-Showing person online/offline status

-posting photos

-Like, Comment on photos

-Share text from this app to others app and vice versa
