package com.example.socialmediaapp.notifications;

public class Response {
    private String success;
}
