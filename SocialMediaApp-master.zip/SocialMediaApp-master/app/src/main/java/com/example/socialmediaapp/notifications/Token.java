package com.example.socialmediaapp.notifications;

public class Token {
    public Token(String token) {
        Token = token;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public Token() {
    }

    String Token;
}
